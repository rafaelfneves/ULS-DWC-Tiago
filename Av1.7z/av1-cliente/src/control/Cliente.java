package control;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

import dao.DAO;

public class Cliente{

	public static void main(String[] args){
	
		//Instance
	DAO dao = new DAO();

	Socket socket;
	InputStream canalEntrada;
	OutputStream canalSa�da;
	BufferedReader entrada;
	PrintWriter sa�da;
	
	try {
		socket = new Socket("127.0.0.1", 4005);
		canalEntrada = socket.getInputStream();
		canalSa�da = socket.getOutputStream();
		entrada = new BufferedReader(new InputStreamReader(canalEntrada));
		sa�da = new PrintWriter(canalSa�da, true);
		
		//Nome
		Scanner nome = new Scanner(System.in);
		System.out.println("Digite o nome do produto: ");
		String leitura1 = nome.nextLine();
		
		//Pre�o
		Scanner preco = new Scanner(System.in);
		System.out.println("Digite o Pre�o do produto: ");
		Double leitura2 = preco.nextDouble();
	
		// Printa a leitura
		sa�da.println(leitura1);
		sa�da.println(leitura2);
		
		String resultado =  entrada.readLine();
		System.out.println(resultado);
		
		//Close
		socket.close();
		nome.close();
		preco.close();
		
	} catch (IOException ioe) {
		ioe.printStackTrace();
	}
	
}
}