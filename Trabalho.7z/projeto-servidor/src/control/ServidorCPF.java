
package control;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorCPF {

	private ServerSocket sckServidor;
	private TratamentoCPF tratamento;
	
	public ServidorCPF() throws IOException {
		this.sckServidor = new ServerSocket(4002);
		
		for (;;) {
			Socket sckCpf;
			InputStream canalEntrada;
			OutputStream canalSaida;
			BufferedReader entrada;
			PrintWriter saida;
			
			sckCpf = this.sckServidor.accept();
			canalEntrada = sckCpf.getInputStream();
			canalSaida = sckCpf.getOutputStream();
			entrada = new BufferedReader(new InputStreamReader(canalEntrada));
			saida = new PrintWriter(canalSaida, true);
			
			while(true) {
				String linhaPedido = entrada.readLine();
				
				if (linhaPedido == null || linhaPedido.length() == 0)
					break;
				String mensagem = linhaPedido;
				tratamento = new TratamentoCPF();
				boolean cpfValido = tratamento.validarCPF(mensagem);
				System.out.println(mensagem);
				if (cpfValido == true) saida.println("CPF: " + mensagem + " é valido.");
				else saida.println("CPF: " + mensagem + " é inválido.");
			}
			sckCpf.close();
		}
	}
}

