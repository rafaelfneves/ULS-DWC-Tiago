package control;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorCPF {

	private ServerSocket sckServidor;
	
	public static boolean validarCPF(String mensagem)
	{
		int soma = 0;
		/*
		mensagem.replace(".", "");
		mensagem.replace(".", "");
		mensagem.replace("-", "");
		*/
		mensagem = mensagem.replace(".", "").replace("-", "");
		
		if (mensagem == "00000000000") return false;
		
	    for (int i = 1; i <= 9; i++)
	    {
	    	soma = soma + Integer.parseInt(mensagem.substring(i - 1, i)) * (11 - i);
	    }

	    float resto = (soma * 10) % 11;
	    
	    if (resto == 10 || resto == 11) resto = 0;
	    if (resto != Integer.parseInt(mensagem.substring(9, 10))) return false;
	    
	    soma = 0;
	    for (int i = 1; i <= 10; i++)
	      soma = soma + Integer.parseInt(mensagem.substring(i - 1, i)) * (12 - i);
	    resto = (soma * 10) % 11;
	    
	    if (resto == 10 || resto == 11) resto = 0;
	    if (resto != Integer.parseInt(mensagem.substring(10, 11))) return false;
	    return true;
	}
	
	public ServidorCPF() throws IOException {
		this.sckServidor = new ServerSocket(4002);
		
		for (;;) {
			Socket sckCpf;
			InputStream canalEntrada;
			OutputStream canalSaida;
			BufferedReader entrada;
			PrintWriter saida;
			
			sckCpf = this.sckServidor.accept();
			canalEntrada = sckCpf.getInputStream();
			canalSaida = sckCpf.getOutputStream();
			entrada = new BufferedReader(new InputStreamReader(canalEntrada));
			saida = new PrintWriter(canalSaida, true);
			
			while(true) {
				String linhaPedido = entrada.readLine();
				
				if (linhaPedido == null || linhaPedido.length() == 0)
					break;
				String mensagem = linhaPedido;
				boolean cpfValido = validarCPF(mensagem);
				
				if (cpfValido == true) saida.println("CPF: " + mensagem + " é valido.");
				else saida.println("CPF: " + mensagem + " é inválido.");
			}
			sckCpf.close();
		}
	}
}
