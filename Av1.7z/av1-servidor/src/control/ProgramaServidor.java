package control;

import java.io.*;

public class ProgramaServidor {

	public static void main(String [] args) throws IOException {
		new TabelaICMS();
		new Servidor();
	}
}

//Calcular ICMS
//cliente que guarde numa lista produtos, que tenha nome, pre�o e pre�o com aliquota 
//perguntar para o servidor a aliquota do arroz, tantos %, aplica o percentual e grava esse produto em uma lista de produtos

//Arroz 7%
//Pao 12%
//Material escolar 18%
//Gasolina 18%
//Energia Eletrica 25%


// Nota do aluno: Professor, n�o consegui aprender sua mat�ria direito, n�o a esse n�vel.
// N�o faz mais sentido cobrar algo no mesmo n�vel que foi ensinado em sala de aula?
// Essa prova faria mais sentido como av2, e o senhor avisou em sala de aula que seria
// prova te�rica, n�o pr�tica, logo acabei estudando a parte te�rica que foi dada.

