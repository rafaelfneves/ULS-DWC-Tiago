package control;

import java.io.*;

public class ProgramaServidor {
	
	public static void main(String [] args) throws IOException {
		new ServidorCPF();
	}
}

// GRUPO: Fabrício Valladares Bertolini / Rafael Fernandes das Neves
