
package control;

public class TratamentoCPF {
	public boolean validarCPF(String mensagem)
	{
		int soma = 0;
		
		mensagem = mensagem.replace(".", "").replace("-", "");

		 if (
		        mensagem.isEmpty()        || mensagem.length() != 11   ||
		        mensagem == "00000000000" || mensagem == "11111111111" ||
				mensagem == "22222222222" || mensagem == "33333333333" ||
				mensagem == "44444444444" || mensagem == "55555555555" ||
				mensagem == "66666666666" || mensagem == "77777777777" ||
				mensagem == "88888888888" || mensagem == "99999999999" 
		    ) return false;
		
	    for (int i = 1; i <= 9; i++)
	    {
	    	soma = soma + Integer.parseInt(mensagem.substring(i - 1, i)) * (11 - i);
	    }

	    float resto = (soma * 10) % 11;
	    
	    if (resto == 10 || resto == 11) resto = 0;
	    if (resto != Integer.parseInt(mensagem.substring(9, 10))) return false;
	    
	    soma = 0;
	    for (int i = 1; i <= 10; i++)
	      soma = soma + Integer.parseInt(mensagem.substring(i - 1, i)) * (12 - i);
	    resto = (soma * 10) % 11;
	    
	    if (resto == 10 || resto == 11) resto = 0;
	    if (resto != Integer.parseInt(mensagem.substring(10, 11))) return false;
	    return true;
	}
}
