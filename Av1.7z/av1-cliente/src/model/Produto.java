package model;

public class Produto {
	private String[] nome;
	private double[] preco;
	private double[] precoComAliquota;	
	
	//Get
	
	public String[] getNome() {
		return nome;
	}	
	public double[] getPreco() {
		return preco;
	}
	public double[] getPrecoComAliquota() {
		return precoComAliquota;
	}

	//Set
	
	public void setNome(String[] nome) {
		this.nome = nome;
	}
	public void setPreco(double[] preco) {
		this.preco = preco;
	}
	public void setPrecoComAliquota(double[] precoComAliquota) {
		this.precoComAliquota = precoComAliquota;
	}
}
