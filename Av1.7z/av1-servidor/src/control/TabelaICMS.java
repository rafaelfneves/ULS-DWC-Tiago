package control;

public class TabelaICMS {

	public static double consultarAliquota(){
		
		
		
		return 0;
	}
};
