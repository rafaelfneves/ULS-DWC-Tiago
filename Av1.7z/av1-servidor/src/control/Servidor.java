package control;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

import control.TabelaICMS;

public class Servidor {
	
	private ServerSocket sckServidor;
	
	public Servidor() throws IOException {
		this.sckServidor = new ServerSocket(4002);
		
		for (;;) 
		{
			Socket sckProduto;
			InputStream canalEntrada;
			OutputStream canalSaida;
			BufferedReader entrada;
			PrintWriter saida;
			
			sckProduto = this.sckServidor.accept();
			canalEntrada = sckProduto.getInputStream();
			canalSaida = sckProduto.getOutputStream();
			entrada = new BufferedReader(new InputStreamReader(canalEntrada));
			saida = new PrintWriter(canalSaida, true);
			
			String linhaPedido = entrada.readLine();
			String mensagem = linhaPedido;
			TabelaICMS = new TabelaICMS();
			double aliquota = TabelaICMS.consultarAliquota();
			System.out.println(mensagem);

			sckProduto.close();
		}
		
	}
}
