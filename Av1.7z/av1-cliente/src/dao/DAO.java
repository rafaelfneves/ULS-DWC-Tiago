package dao;

import java.util.ArrayList;
import model.Produto;
import control.Cliente;

public class DAO 
{	
	public static void adicionarProduto()	
	{
		Produto produto = new Produto();
		Cliente cliente = new Cliente();
		
		//Lista
		ArrayList lista = new ArrayList() {
			String[] nome = produto.getNome();
			double[] preco = produto.getPreco();
			double[] precoAliquota = produto.getPrecoComAliquota();
		
		};	
		
		String[] nome = {"arroz", "pao", "Material Escolar","Gasolina", "Energia El�trica"};
		double[] precoAliquota = {0.07, 0.12, 0.18, 0.18, 0.25};
	}
}
